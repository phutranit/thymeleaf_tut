package com.itphutran.constant;

public class Defines {
	public static final int ROW_COUNT = 10;
}
