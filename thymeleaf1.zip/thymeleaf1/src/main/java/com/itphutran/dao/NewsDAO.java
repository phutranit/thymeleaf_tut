package com.itphutran.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.stereotype.Repository;

import com.itphutran.model.News;
@Repository
public class NewsDAO {
	private ArrayList<News> listNews;
	
	public NewsDAO() {
		listNews =  new ArrayList<News>();
	}
	
	public ArrayList<News> getItems(){
		listNews.add(new News(1, "Hôm nay trời mưa to", "trời mưa to thì làm gì phải sợ 1", "trời mưa to thì làm gì phải sợ 1 ...", new Timestamp(new Date().getTime()), 1));
		listNews.add(new News(2, "Hôm nay trời mưa to 2", "trời mưa to thì làm gì phải sợ 2", "trời mưa to thì làm gì phải sợ 2 ...", new Timestamp(new Date().getTime()), 1));
		listNews.add(new News(3, "Hôm nay trời mưa to 3", "trời mưa to thì làm gì phải sợ 3 ", "trời mưa to thì làm gì phải sợ 3...", new Timestamp(new Date().getTime()), 1));
		listNews.add(new News(4, "Hôm nay trời mưa to 4", "trời mưa to thì làm gì phải sợ 4", "trời mưa to thì làm gì phải sợ 4...", new Timestamp(new Date().getTime()), 1));
		return listNews;
	}
	
	public News getItem(int id) {
		return listNews.get(id - 1);
	}
}
