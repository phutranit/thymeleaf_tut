package com.itphutran.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.itphutran.model.Cat;
@Repository
public class CatDAO {
	
	public ArrayList<Cat> getItems(){
		ArrayList<Cat> listCat = new ArrayList<Cat>();
		listCat.add(new Cat(1, "Thể thao"));
		listCat.add(new Cat(2, "Thời sự"));
		listCat.add(new Cat(3, "Kinh doanh"));
		listCat.add(new Cat(4, "Góc nhìn"));
		listCat.add(new Cat(5, "Bà tám"));
		return listCat;
	}
}
