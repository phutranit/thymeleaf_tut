package com.itphutran.model;

import java.sql.Timestamp;

public class News {
	private int newsId;
	private String name;
	private String description;
	private String detail;
	private Timestamp dateCreate;
	private int catId;
	public int getNewsId() {
		return newsId;
	}
	public void setNewsId(int newsId) {
		this.newsId = newsId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public Timestamp getDateCreate() {
		return dateCreate;
	}
	public void setDateCreate(Timestamp dateCreate) {
		this.dateCreate = dateCreate;
	}
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	
	public News() {
		super();
	}
	public News(int newsId, String name, String description, String detail, Timestamp dateCreate, int catId) {
		super();
		this.newsId = newsId;
		this.name = name;
		this.description = description;
		this.detail = detail;
		this.dateCreate = dateCreate;
		this.catId = catId;
	}
}	
