package com.itphutran.model;

public class Cat {
	private int catID;
	private String catName;
	
	public int getCatID() {
		return catID;
	}
	public void setCatID(int catID) {
		this.catID = catID;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public Cat() {
		super();
	}
	public Cat(int catID, String catName) {
		this.catID = catID;
		this.catName = catName;
	}
}
