package com.itphutran.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class Register {
	@NotEmpty
	private String fullname;
	@NotEmpty
	private String username;
	@NotEmpty
	private String password;
	@NotEmpty
	private String sex;
	@NotEmpty
	private String linkFB;
	@Min(10)
	private int city;
	
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getLinkFB() {
		return linkFB;
	}
	public void setLinkFB(String linkFB) {
		this.linkFB = linkFB;
	}
	public int getCity() {
		return city;
	}
	public void setCity(int city) {
		this.city = city;
	}
	public Register() {
		super();
	}
	public Register(String fullname, String username, String password, String sex, String linkFB, int city) {
		super();
		this.fullname = fullname;
		this.username = username;
		this.password = password;
		this.sex = sex;
		this.linkFB = linkFB;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Register [fullname=" + fullname + ", username=" + username + ", password=" + password + ", sex=" + sex
				+ ", linkFB=" + linkFB + ", city=" + city + "]";
	}
	
}
