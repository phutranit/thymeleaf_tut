package com.itphutran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.dao.CatDAO;

@Controller
@RequestMapping("/admin/news")
public class AdminNewsController {
	@Autowired
	private CatDAO catDAO;
	
	@RequestMapping("")
	public String index() {
		return "admin/indexNews";
	}
	
	@RequestMapping("/add")
	public String add(Model model) {
		model.addAttribute("listCat", catDAO.getItems());
		return "admin/addNews";
	}
}
