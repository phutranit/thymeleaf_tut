package com.itphutran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.dao.CatDAO;
import com.itphutran.dao.NewsDAO;

@Controller
public class PublicNewsController {
	@Autowired
	private CatDAO catDAO;
	
	@Autowired
	private NewsDAO newsDAO;
	
	@ModelAttribute
	public void commonObjects(Model model) {
		model.addAttribute("listCat", catDAO.getItems());
	}
	
	@RequestMapping("detail/{id}")
	public String index(@PathVariable("id") int id,Model model) {
		model.addAttribute("objNews", newsDAO.getItem(id));
		return "chitiet";
	}
	
	@RequestMapping("news")
	public String news(Model model) {
		model.addAttribute("listNews",newsDAO.getItems());
		return "tintuc";
	}
	
	@RequestMapping("cat")
	public String cat() {
		return "danhmuc";
	}
}
