package com.itphutran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.constant.Defines;
import com.itphutran.dao.CatDAO;

@Controller
public class PublicIndexController {
	@Autowired
	private CatDAO catDAO;
	@Autowired
	@Qualifier("defines")
	private Defines defines;
	
	@ModelAttribute
	public void commonObjects(Model model) {
		model.addAttribute("listCat", catDAO.getItems());
		model.addAttribute("defines", defines);
	}
	
	@RequestMapping("")
	public String index() {
		return "index";
	}
}
