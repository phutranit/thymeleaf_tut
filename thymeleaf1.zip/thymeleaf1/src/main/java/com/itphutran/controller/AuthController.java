package com.itphutran.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.itphutran.dao.CatDAO;
import com.itphutran.model.User;

@Controller
public class AuthController {
	@Autowired
	private CatDAO catDAO;
	
	@ModelAttribute
	public void commonObjects(Model model) {
		model.addAttribute("listCat", catDAO.getItems());
	}
	
	@RequestMapping(value="login",method=RequestMethod.POST)
	public String login(@ModelAttribute("user") User user,Model model,HttpSession session) {
		if(!"admin".equals(user.getUsername()) && !"123456".equals(user.getPassword())) {
			model.addAttribute("msg", "Yor enter wrong username or password!");
			return "login";
		}
		session.setAttribute("userinfo", user);
		return "redirect:/";
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String login(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}
}
