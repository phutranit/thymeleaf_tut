package com.itphutran.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.itphutran.model.City;
import com.itphutran.model.Register;

@Controller
public class RegisterController {
	
	
	@ModelAttribute
	public void commonObjects(Model model) {
		ArrayList<City> listReg = new ArrayList<City>();
		listReg.add(new City(1, "TP.Hồ Chí Minh"));
		listReg.add(new City(2, "TP.Đà Nẵng"));
		listReg.add(new City(3, "TP.Hà Nội"));
		listReg.add(new City(4, "TP.Huế"));
		model.addAttribute("listReg", listReg);
	}
	
	
	@RequestMapping(value="reg",method=RequestMethod.POST)
	public String reg(@Valid @ModelAttribute("reg") Register reg,BindingResult rs,Model model) {
		if(rs.hasErrors()) {
			List<ObjectError> ers = rs.getAllErrors();
			for (ObjectError objectError : ers) {
				System.out.println(objectError.getDefaultMessage());
			}
			return "register";
		}
		System.out.println(reg.toString());
		model.addAttribute("reg", reg);
		return "register";
	}
	
	@RequestMapping(value="reg",method=RequestMethod.GET)
	public String reg(Model model) {
		model.addAttribute("reg", new Register());
		return "register";
	}
}
