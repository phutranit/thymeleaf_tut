package com.itphutran.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.dao.CatDAO;


@Controller
@RequestMapping("/ajax")
public class AjaxController {
	@Autowired
	private CatDAO catDAO;
	
	@PostMapping("/addNewsChangSelection")
	public String addNewsChangSelection() {
		return "templates/fragments/ajax/index";
	}
	
	@PostMapping("/fragment")
	public String ajaxFragment(Model model){
		model.addAttribute("listCat", catDAO.getItems());
		return "admin/addNews :: responseSelect";
	}
}
